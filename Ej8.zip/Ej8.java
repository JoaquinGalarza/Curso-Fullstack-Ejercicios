public class Ej8 {
    public static void main(String[] args) {
        Persona persona1 = new Persona();
        persona1.setEdad(21);
        persona1.setNombre("Choerry");
        persona1.setTelefono("08");
        System.out.println("La edad de la persona es: "+persona1.getEdad());
        System.out.println("El nombre de la persona es: "+persona1.getNombre());
        System.out.println("EL telefono de la persona es: "+persona1.getTelefono());
    }
}
